<!DOCTYPE html>
<html>
<head>
    <title>OurEasyTrade.xyz</title>
</head>
<body>
    <h1>{{ $details['title'] }}</h1>
    <h3>Login Credentials</h3>
    <p>{{ $details['username'] }}</p>
    <p>{{ $details['password'] }}</p>


    <p>Thank you</p>
</body>
</html>
