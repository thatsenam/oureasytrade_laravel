@extends('voyager::master')


@section('css')
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <link href="https://unpkg.com/tailwindcss@^1.0/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('css/admin-style.css') }}">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js" integrity="sha512-2ImtlRlf2VVmiGZsjm9bEyhjGW4dU7B6TNwh/hx/iSByxNENtj3WVE6o/9Lj4TJeVXPi4bnOIMXFIJJAeufa0A==" crossorigin="anonymous"></script>
@endsection

@section('content')
    <!-- component -->

    <div  class="container m-2 font-bold bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert" >
    Under DEVELOPMENT.
    </div>

@endsection

@section('javascript')
    <script type="text/javascript" src="{{ asset('js/admin.js') }}"></script>
@endsection
