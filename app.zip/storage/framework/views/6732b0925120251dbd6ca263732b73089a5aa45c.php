<!DOCTYPE html>
<html>
<head>
    <title>OurEasyTrade.xyz</title>
</head>
<body>
    <h1><?php echo e($details['title']); ?></h1>
    <h3>Login Credentials</h3>
    <p><?php echo e($details['username']); ?></p>
    <p><?php echo e($details['password']); ?></p>


    <p>Thank you</p>
</body>
</html>
<?php /**PATH C:\laragon\www\oureasytrade\resources\views/mail\user_info.blade.php ENDPATH**/ ?>